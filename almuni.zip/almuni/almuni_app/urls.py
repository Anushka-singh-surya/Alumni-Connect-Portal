
from django.urls import path,include
from . import views
urlpatterns = [
     
    path('',views.home,name="home" ),
    path("contact/",views.contact,name="contact"),
    path("login/",views.login,name="login"),
    path("view_almuni/",views.view_almuni,name = "view_almuni"),
    path("add_story/",views.add_story,name = "add_story"),
    path("view_story/<str:email>",views.view_story,name = "view_story"),
    path("logout/",views.logout,name = "logout"),
    path("edit_profile/",views.edit_profile,name = "logout"),


    

    
]