from django.contrib import admin
from . models import Event,Alumni_Detail,Success_Story,Notice,Contact
admin.site.register(Event)
admin.site.register(Alumni_Detail)
admin.site.register(Success_Story)
admin.site.register(Notice)
admin.site.register(Contact)

