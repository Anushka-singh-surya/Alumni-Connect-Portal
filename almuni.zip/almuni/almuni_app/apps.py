from django.apps import AppConfig


class AlmuniAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'almuni_app'
