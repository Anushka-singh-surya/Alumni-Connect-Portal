from django.db import models
from django.utils import timezone


class Notice(models.Model):
    notice_content = models.CharField(max_length=100,default="")
    notice_date = models.DateField(default=timezone.now)
class Success_Story(models.Model):
    alumni_id = models.CharField(max_length=7,default="")
    subject = models.CharField(max_length=30,default="")
    text = models.TextField(default="")
    date = models.DateField(default=timezone.now)

class Alumni_Detail(models.Model):
    name = models.CharField(max_length=30,default="")
    address = models.CharField(max_length=30,default="")
    email = models.CharField(max_length=30,default="")
    phone = models.CharField(max_length=30,default="")
    gender = models.CharField(max_length=30,default="")
    course_name = models.CharField(max_length=30,default="")
    passing_year = models.CharField(max_length=30,default="")
    alumni_id = models.CharField(max_length=30,default="")
    password = models.CharField(max_length=30,default="")
    pic = models.ImageField(upload_to="profile_pic/",default="",blank=True)
class Event(models.Model):
    event_name = models.CharField(max_length=30,default="")
    event_venue = models.CharField(max_length=30,default="")
    event_organizer = models.CharField(max_length=30,default="")
    event_description = models.TextField(default="")
    event_pic = models.ImageField(upload_to="event_pic/",default=" ",blank=True)
    event_date = models.DateField(default=timezone.now)
    
class Contact(models.Model):
    name=models.CharField(max_length=20)
    email = models.CharField(max_length=50)
    message = models.TextField()
