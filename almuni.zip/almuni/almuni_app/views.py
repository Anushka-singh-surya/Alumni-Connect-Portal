from django.shortcuts import render,redirect
from .models import Event,Contact,Alumni_Detail,Success_Story
from django.contrib import messages
data = Event.objects.all()
def home(request):
    if request.method=="GET":
        return render(request,'almuni_app/html/index.html',{"events":data})
    if request.method=="POST":
        name = request.POST["name"]
        email = request.POST["email"]
        message = request.POST["message"]
        contact_obj = Contact(name=name,email=email,message=message)
        contact_obj.save()
        messages.success(request,"thank you .................")
        return render(request,'almuni_app/html/index.html',{"events":data})

def contact(request):
    if request.method=="GET":
        return render(request,'almuni_app/html/index.html',{"events":data})
    if request.method=="POST":
        name = request.POST["name"]
        email = request.POST["email"]
        message = request.POST["message"]
        contact_obj = Contact(name=name,email=email,message=message)
        contact_obj.save()
        messages.success(request,"thank you .................")
        return render(request,'almuni_app/html/index.html',{"events":data})

def login(request):
    if request.method=="GET":
        return render(request,"almuni_app/almuni/login.html")
    if request.method=="POST":
        email = request.POST["email"]
        password = request.POST["password"]
        status = Alumni_Detail.objects.filter(email=email,password=password)
        print(status)
        if len(status)>0:
            request.session["session_key"]=email
            data={
                "almuni_details":status[0]
            }
            return render(request,"almuni_app/almuni/almuni_home.html",data)
        else:
            messages.success(request,"error when we login........")
            return redirect("login")
def view_almuni(request):
    almuni_details = Alumni_Detail.objects.all()
    if request.method=="GET": 
        return render(request,"almuni_app/almuni/view_almuni.html",{"almuni_details":almuni_details,"view":"random"})
    if request.method=="POST":
        course = request.POST["course"]
        course = course.upper()
        year = request.POST["year"]
        view=""
        if year=="":
            almuni_details= Alumni_Detail.objects.filter(course_name=course)
            view="Course- "+course
        elif course=="":
            almuni_details=Alumni_Detail.objects.filter(passing_year=year)
            view="year-"+year
        else:
            almuni_details=Alumni_Detail.objects.filter(passing_year=year,course_name=course)
            view =year+"/"+course        
        if len(almuni_details)==0:
            messages.info(request,"please provide a valid keyword for search almuni or no almuni exits for this year and course ")
            return render(request,"almuni_app/almuni/view_almuni.html",{"almuni_details":almuni_details,"view":view})
        else:
            return render(request,"almuni_app/almuni/view_almuni.html",{"almuni_details":almuni_details,"view":view})
        

def view_story(request,email):
    story = Success_Story.objects.filter(alumni_id=email)
    return render(request,'almuni_app/almuni/view_story.html',{"data":story})
def add_story(request):
    if request.method=="GET":
        return render(request,'almuni_app/almuni/add_story.html')
    if request.method=="POST":
        subject = request.POST["subject"]
        story = request.POST["story"]
        email = request.session['session_key']
        obj = Success_Story(alumni_id=email,subject=subject,text=story)
        obj.save()
        messages.success(request,"thank you .................")
        return redirect("add_story")
def logout(request):
    del request.session
    return redirect("home")
def edit_profile(request):
    email = request.session["session_key"]
    data = Alumni_Detail.objects.filter(email=email)
    if request.method=="GET":
        return render(request,"almuni_app/almuni/edit_profile.html",{"key_data":data})
    if request.method=="POST":
        alumni = Alumni_Detail.objects.get(email=email)
        alumni.name = request.POST["name"]
        alumni.phone = request.POST["phone"]
        alumni.address = request.POST["address"]
        alumni.save()
        context={
            "almuni_details":alumni
        }
        return render(request,"almuni_app/almuni/almuni_home.html",context)